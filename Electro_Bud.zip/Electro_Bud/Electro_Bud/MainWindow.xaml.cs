﻿using System.Windows;

namespace Electro_Bud
{
    public partial class MainWindow : Window
    {

    }
}
